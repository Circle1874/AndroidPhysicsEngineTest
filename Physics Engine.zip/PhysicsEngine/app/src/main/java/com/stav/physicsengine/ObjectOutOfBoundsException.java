package com.stav.physicsengine;

public class ObjectOutOfBoundsException extends Exception {
    public ObjectOutOfBoundsException(String errorMessage){
        super(errorMessage);
    }
}
